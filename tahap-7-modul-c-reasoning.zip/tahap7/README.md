# Tahap 7 — Modul C: Constrained LLM Reasoning

Implementasi lengkap Tahap 7 dari panduan implementasi Poultry GraphRAG-Vet,
sudah disesuaikan dengan **Design Addendum: Chat Persistence & Riwayat Kandang**.

## ⚠️ Batasan Validasi

Sama seperti Tahap 6, panggilan LLM sungguhan (`AnthropicLLMClient`) **tidak
bisa diuji** di sandbox ini (tidak ada akses jaringan ke `api.anthropic.com`).
Seluruh **75 test** (55 dari Tahap 2 + 20 baru) berjalan dengan `FakeLLMClient`
yang disuntikkan manual — memvalidasi ORKESTRASI (kapan LLM dipanggil, apa
yang dikirim, bagaimana hasilnya digabung), bukan kualitas jawaban LLM
sungguhan. WAJIB diuji manual dengan API key asli sebelum produksi.

## Keputusan Desain Inti: Minimalkan Bagian Generatif

LLM **HANYA** mengisi 2 hal: `differential_note` per kandidat penyakit, dan
`overall_uncertainty`. Semua field lain (`evidence`, `recommended_checks`,
`recommended_mitigations`, `medical_reference`, `notifiable_notice`,
`severity`) dibangun **100% deterministik** langsung dari `GraphContext` —
lihat `deterministic_builders.py` dan `severity_selector.py`. Ini
meminimalkan permukaan hallucination sedapat mungkin dibanding pendekatan
"LLM menulis semua field".

## Perubahan ke File Tahap 2 (non-breaking)

`domain/entities/case.py` — `attach_reasoning_result()` ditambah 2
parameter baru dengan default `None`: `overall_uncertainty`,
`notifiable_notice`. Sudah diverifikasi: 55 test lama Tahap 2 tetap
PASSED setelah perubahan ini.

## Struktur File

```
src/poultry_graphrag/
├─ infrastructure/llm/client.py         # Protocol LLMClient + AnthropicLLMClient (untested live)
└─ pipelines/module_c_reasoning/
   ├─ dto.py                            # CaseContextInput, ChatMessage, ReasoningOutput,
   │                                     #   ReasoningLLMResponse (schema pydantic utk LLM)
   ├─ prompt_constraints.py             # DIAGNOSTIC_SYSTEM_PROMPT & CHAT_SYSTEM_PROMPT (+rule #11)
   ├─ severity_selector.py              # compute_case_severity() -- worst-case/precautionary
   ├─ deterministic_builders.py         # SEMUA output non-LLM dibangun di sini
   ├─ fallback_template.py              # insufficient_data, TANPA panggil LLM sama sekali
   └─ reasoner.py                       # reason() Tier 1, reason_chat_turn() untuk chat

tests/unit/pipelines/module_c/           # 20 test, FakeLLMClient, tidak butuh API live
```

## Implementasi Design Addendum di Sini

- ✅ Rule #11 (riwayat kandang HANYA informasional) — ada di `CHAT_SYSTEM_PROMPT`,
  dites di `test_chat_turn_uses_chat_system_prompt_with_rule_11`
- ✅ Riwayat kandang TIDAK masuk ke prompt Tier 1 — dites di
  `test_diagnostic_prompt_does_not_include_cage_history`
- ✅ Retrieval scoping ke `confirmed_disease` saat `CONFIRMED_SICK` — dites di
  `test_chat_turn_includes_confirmed_disease_when_present`
  (catatan: query scoping Modul B sungguhan ada di Tahap 8, di sini baru
  memastikan prompt-nya menyertakan info status/confirmed_disease dengan benar)

## Cara Pakai

1. Copy `src/` dan `tests/` ke lokasi yang sama di repo Anda (akan overlay
   `domain/entities/case.py` yang sudah diupdate).
2. `pip install pydantic pytest`
3. `pytest tests/ -v` — harus 75 passed.
4. Sebelum produksi: uji `AnthropicLLMClient` dengan API key asli, verifikasi
   `generate_structured()` benar-benar menghasilkan JSON yang match schema
   `ReasoningLLMResponse` secara konsisten (model kadang butuh prompt
   tuning tambahan untuk kepatuhan format JSON yang ketat).
