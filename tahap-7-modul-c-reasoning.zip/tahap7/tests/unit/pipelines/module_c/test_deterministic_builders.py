"""Unit test untuk deterministic_builders.py -- bagian TANPA LLM sama sekali."""
from poultry_graphrag.pipelines.module_c_reasoning.deterministic_builders import (
    build_disease_action_bundles,
    build_evidence_strings,
    build_notifiable_notice,
    build_unique_inspection_actions,
)

from .conftest import make_candidate
from poultry_graphrag.infrastructure.neo4j.dto import AttributedFeature, RawInspectionAction


def test_build_evidence_strings_includes_specificity_and_onset_stage():
    candidate = make_candidate(
        visual_features=[
            AttributedFeature(
                name="lowered_head_posture", specificity="high", onset_stage="early", mechanism="x"
            )
        ]
    )
    evidence = build_evidence_strings(candidate)
    assert evidence == ["lowered_head_posture (high specificity, early stage)"]


def test_build_evidence_strings_handles_missing_specificity_gracefully():
    candidate = make_candidate(
        visual_features=[
            AttributedFeature(name="lowered_head_posture", specificity=None, onset_stage=None, mechanism=None)
        ]
    )
    evidence = build_evidence_strings(candidate)
    assert evidence == ["lowered_head_posture"]


def test_build_unique_inspection_actions_deduplicates_across_candidates(two_candidate_graph_context):
    actions = build_unique_inspection_actions(two_candidate_graph_context.candidates)
    # kedua kandidat sama-sama merekomendasikan "observe_breathing" -- harus muncul 1x saja
    names = [a.name for a in actions]
    assert names.count("observe_breathing") == 1


def test_build_disease_action_bundles_keeps_actions_separate_per_disease(two_candidate_graph_context):
    bundles = build_disease_action_bundles(two_candidate_graph_context.candidates)

    assert set(bundles.keys()) == {"Newcastle Disease", "Infectious Bronchitis"}
    assert bundles["Newcastle Disease"].mitigations[0].name == "isolate_bird"
    assert bundles["Infectious Bronchitis"].mitigations[0].name == "increase_ventilation"
    # Newcastle Disease tidak punya medical_treatments di fixture -- harus kosong, bukan error
    assert bundles["Newcastle Disease"].medical_references == ()
    assert bundles["Infectious Bronchitis"].medical_references[0].treatment_name == "Amoxicillin"


def test_build_notifiable_notice_none_when_no_candidate_notifiable():
    candidate = make_candidate(notifiable=False)
    assert build_notifiable_notice([candidate]) is None


def test_build_notifiable_notice_present_when_candidate_notifiable(two_candidate_graph_context):
    notice = build_notifiable_notice(two_candidate_graph_context.candidates)
    assert notice is not None
    assert "Newcastle Disease" in notice
    assert "wajib lapor" in notice.lower()


def test_build_notifiable_notice_lists_multiple_notifiable_diseases():
    a = make_candidate(disease_name="Avian Influenza", notifiable=True)
    b = make_candidate(disease_name="Newcastle Disease", notifiable=True)
    notice = build_notifiable_notice([a, b])
    assert "Avian Influenza" in notice
    assert "Newcastle Disease" in notice
