"""Unit test untuk severity_selector.py -- prinsip worst-case/precautionary."""
from poultry_graphrag.domain.value_objects.enums import SeverityLevel
from poultry_graphrag.pipelines.module_c_reasoning.severity_selector import (
    compute_case_severity,
)

from .conftest import make_candidate
from poultry_graphrag.infrastructure.neo4j.dto import AttributedFeature


def test_compute_case_severity_picks_highest_among_candidates():
    low_risk = make_candidate(
        disease_name="A",
        base_severity="low",
        visual_features=[AttributedFeature(name="x", specificity="low", onset_stage="early", mechanism=None)],
    )
    high_risk = make_candidate(
        disease_name="B",
        base_severity="critical",
        visual_features=[AttributedFeature(name="y", specificity="high", onset_stage="late", mechanism=None)],
    )
    result = compute_case_severity([low_risk, high_risk])
    assert result.level == SeverityLevel.CRITICAL


def test_compute_case_severity_picks_worst_onset_stage_per_candidate():
    """Kandidat sama, tapi ada 2 fitur match dengan onset_stage beda --
    harus pilih yang PALING TELAT (late), bukan yang pertama ditemukan."""
    candidate = make_candidate(
        base_severity="medium",
        visual_features=[
            AttributedFeature(name="a", specificity="low", onset_stage="early", mechanism=None),
            AttributedFeature(name="b", specificity="high", onset_stage="late", mechanism=None),
        ],
    )
    result = compute_case_severity([candidate])
    assert result.onset_stage == "late"


def test_compute_case_severity_returns_none_for_empty_candidates():
    assert compute_case_severity([]) is None


def test_compute_case_severity_returns_none_if_no_candidate_has_onset_stage():
    candidate = make_candidate(
        visual_features=[AttributedFeature(name="x", specificity="high", onset_stage=None, mechanism=None)]
    )
    assert compute_case_severity([candidate]) is None


def test_compute_case_severity_skips_candidate_with_invalid_enum_value():
    """Data KG bermasalah (base_severity tidak dikenal) tidak boleh crash
    seluruh perhitungan -- kandidat itu dilewati, kandidat lain tetap diproses."""
    bad_candidate = make_candidate(
        disease_name="Bad",
        base_severity="not_a_real_severity",
        visual_features=[AttributedFeature(name="x", specificity="high", onset_stage="early", mechanism=None)],
    )
    good_candidate = make_candidate(
        disease_name="Good",
        base_severity="high",
        visual_features=[AttributedFeature(name="y", specificity="high", onset_stage="early", mechanism=None)],
    )
    result = compute_case_severity([bad_candidate, good_candidate])
    assert result is not None
    assert result.base_severity == "high"
