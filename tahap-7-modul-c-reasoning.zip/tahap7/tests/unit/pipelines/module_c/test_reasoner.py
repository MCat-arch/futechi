"""
Unit test untuk reasoner.py -- LLM DISUNTIK sebagai FakeLLMClient, tidak
pernah memanggil API sungguhan. Fokus pengujian: apakah orkestrasi
deterministik-vs-generatif berjalan sesuai desain (LLM HANYA mengisi
differential_note & overall_uncertainty, sisanya dari graph).
"""
from poultry_graphrag.infrastructure.neo4j.dto import GraphContext
from poultry_graphrag.pipelines.module_c_reasoning.dto import (
    CaseContextInput,
    ChatMessage,
    DifferentialNoteItem,
    ReasoningLLMResponse,
)
from poultry_graphrag.pipelines.module_c_reasoning.reasoner import (
    reason,
    reason_chat_turn,
)
from poultry_graphrag.domain.value_objects.observations import EnvironmentSnapshot


class FakeLLMClient:
    """
    Fake LLMClient -- generate_structured() mengembalikan respons yang
    SUDAH ditentukan test (canned), generate() mengembalikan string tetap.
    Mencatat prompt yang diterima untuk assert isi konteksnya.
    """

    def __init__(self, structured_response=None, text_response="respons chat contoh"):
        self._structured_response = structured_response
        self._text_response = text_response
        self.last_system_prompt: str | None = None
        self.last_user_prompt: str | None = None

    def generate(self, system_prompt: str, user_prompt: str) -> str:
        self.last_system_prompt = system_prompt
        self.last_user_prompt = user_prompt
        return self._text_response

    def generate_structured(self, system_prompt: str, user_prompt: str, schema):
        self.last_system_prompt = system_prompt
        self.last_user_prompt = user_prompt
        return self._structured_response


def _sample_case_context() -> CaseContextInput:
    from poultry_graphrag.domain.value_objects.observations import VisualFeatureObservation

    return CaseContextInput(
        cage_id="B40",
        zone_id="Z3",
        visual_features=[VisualFeatureObservation(name="lowered_head_posture", confidence=0.88)],
        environment_snapshot=EnvironmentSnapshot(30.5, 76, 22, normalized_conditions=("humidity_attention",)),
    )


# ----------------------------------------------------------------------
# reason() -- Tier 1
# ----------------------------------------------------------------------
def test_reason_returns_fallback_without_calling_llm_when_context_empty():
    fake_llm = FakeLLMClient()
    result = reason(_sample_case_context(), GraphContext(candidates=[]), fake_llm)

    assert result.related_conditions == []
    assert result.severity is None
    assert fake_llm.last_system_prompt is None  # LLM TIDAK PERNAH dipanggil
    assert fake_llm.last_user_prompt is None


def test_reason_uses_llm_only_for_differential_note_and_uncertainty(two_candidate_graph_context):
    fake_response = ReasoningLLMResponse(
        differential_notes=[
            DifferentialNoteItem(
                disease_name="Newcastle Disease",
                differential_note="Lebih mungkin karena specificity tinggi.",
            ),
            DifferentialNoteItem(
                disease_name="Infectious Bronchitis",
                differential_note="Kurang didukung, specificity rendah.",
            ),
        ],
        overall_uncertainty="Sedang -- 2 kandidat dengan gejala tumpang tindih.",
    )
    fake_llm = FakeLLMClient(structured_response=fake_response)

    result = reason(_sample_case_context(), two_candidate_graph_context, fake_llm)

    # differential_note & overall_uncertainty DARI LLM
    nd = {c.disease_name: c.differential_note for c in result.related_conditions}
    assert nd["Newcastle Disease"] == "Lebih mungkin karena specificity tinggi."
    assert result.overall_uncertainty == "Sedang -- 2 kandidat dengan gejala tumpang tindih."

    # evidence, checks, mitigations, notifiable_notice -- DETERMINISTIK, bukan dari LLM
    assert result.related_conditions[0].evidence != ()
    assert len(result.recommended_checks) > 0
    assert "Newcastle Disease" in result.disease_actions
    assert result.notifiable_notice is not None  # Newcastle Disease notifiable=True di fixture
    assert result.severity is not None


def test_reason_falls_back_to_default_note_if_llm_omits_a_candidate(two_candidate_graph_context):
    """LLM cuma kasih catatan utk 1 dari 2 kandidat -- kandidat yang tidak
    disebut LLM tetap harus dapat related_conditions entry (dengan default
    note), TIDAK boleh hilang dari daftar."""
    fake_response = ReasoningLLMResponse(
        differential_notes=[
            DifferentialNoteItem(disease_name="Newcastle Disease", differential_note="Catatan A"),
        ],
        overall_uncertainty="Sedang",
    )
    fake_llm = FakeLLMClient(structured_response=fake_response)

    result = reason(_sample_case_context(), two_candidate_graph_context, fake_llm)

    assert len(result.related_conditions) == 2  # tetap 2, sesuai jumlah kandidat graph
    bronchitis = next(c for c in result.related_conditions if c.disease_name == "Infectious Bronchitis")
    assert "Tidak ada catatan diferensial" in bronchitis.differential_note


def test_diagnostic_prompt_does_not_include_cage_history(two_candidate_graph_context):
    """Design Addendum Keputusan 3: riwayat kandang TIDAK boleh masuk ke
    prompt Tier 1 (diagnostic), hanya boleh di chat."""
    fake_response = ReasoningLLMResponse(differential_notes=[], overall_uncertainty="x")
    fake_llm = FakeLLMClient(structured_response=fake_response)

    reason(_sample_case_context(), two_candidate_graph_context, fake_llm)

    assert "RIWAYAT" not in fake_llm.last_user_prompt.upper()


# ----------------------------------------------------------------------
# reason_chat_turn()
# ----------------------------------------------------------------------
def test_chat_turn_includes_cage_history_when_provided(two_candidate_graph_context):
    fake_llm = FakeLLMClient(text_response="jawaban chat")

    reason_chat_turn(
        graph_context=two_candidate_graph_context,
        cage_history_summary="2026-07-15: dikonfirmasi Newcastle Disease",
        case_status="PENDING_CONFIRMATION",
        confirmed_disease=None,
        messages=[ChatMessage(role="user", content="kenapa dicurigai ND?")],
        llm_client=fake_llm,
    )

    assert "CATATAN RIWAYAT" in fake_llm.last_user_prompt
    assert "informasional" in fake_llm.last_user_prompt.lower()
    assert "2026-07-15" in fake_llm.last_user_prompt


def test_chat_turn_uses_chat_system_prompt_with_rule_11():
    fake_llm = FakeLLMClient()
    reason_chat_turn(
        graph_context=GraphContext(candidates=[]),
        cage_history_summary=None,
        case_status="PENDING_CONFIRMATION",
        confirmed_disease=None,
        messages=[],
        llm_client=fake_llm,
    )
    assert "11." in fake_llm.last_system_prompt
    assert "riwayat kandang" in fake_llm.last_system_prompt.lower()


def test_chat_turn_includes_confirmed_disease_when_present(two_candidate_graph_context):
    fake_llm = FakeLLMClient()
    reason_chat_turn(
        graph_context=two_candidate_graph_context,
        cage_history_summary=None,
        case_status="CONFIRMED_SICK",
        confirmed_disease="Newcastle Disease",
        messages=[ChatMessage(role="user", content="dosis obatnya?")],
        llm_client=fake_llm,
    )
    assert "Newcastle Disease" in fake_llm.last_user_prompt
    assert "CONFIRMED_SICK" in fake_llm.last_user_prompt


def test_chat_turn_returns_llm_text_directly():
    fake_llm = FakeLLMClient(text_response="Ini jawaban dari LLM")
    result = reason_chat_turn(
        graph_context=GraphContext(candidates=[]),
        cage_history_summary=None,
        case_status="PENDING_CONFIRMATION",
        confirmed_disease=None,
        messages=[],
        llm_client=fake_llm,
    )
    assert result == "Ini jawaban dari LLM"
