"""Fixture bersama untuk test Modul C."""
import pytest

from poultry_graphrag.infrastructure.neo4j.dto import (
    AttributedFeature,
    DiseaseCandidate,
    GraphContext,
    MatchedEnvironmentCondition,
    RawInspectionAction,
    RawMedicalTreatment,
    RawMitigationAction,
)


def make_candidate(
    disease_id="DIS-001",
    disease_name="Newcastle Disease",
    base_severity="high",
    notifiable=False,
    visual_features=None,
    symptoms=None,
    environment=None,
    inspections=None,
    mitigations=None,
    treatments=None,
) -> DiseaseCandidate:
    return DiseaseCandidate(
        disease_id=disease_id,
        disease_name=disease_name,
        desc="deskripsi contoh",
        base_severity=base_severity,
        notifiable=notifiable,
        matched_visual_features=visual_features or [],
        related_symptoms=symptoms or [],
        matched_environment=environment or [],
        inspection_actions=inspections or [],
        mitigation_actions=mitigations or [],
        medical_treatments=treatments or [],
    )


@pytest.fixture
def two_candidate_graph_context() -> GraphContext:
    candidate_a = make_candidate(
        disease_id="DIS-001",
        disease_name="Newcastle Disease",
        base_severity="critical",
        notifiable=True,
        visual_features=[
            AttributedFeature(
                name="lowered_head_posture",
                specificity="high",
                onset_stage="early",
                mechanism="gangguan neurologis awal",
            )
        ],
        environment=[MatchedEnvironmentCondition(name="humidity_attention", strength="medium")],
        inspections=[RawInspectionAction(name="observe_breathing", instruction="Dengarkan napas")],
        mitigations=[RawMitigationAction(name="isolate_bird", instruction="Pisahkan ayam", priority="high")],
        treatments=[],
    )
    candidate_b = make_candidate(
        disease_id="DIS-002",
        disease_name="Infectious Bronchitis",
        base_severity="medium",
        notifiable=False,
        visual_features=[
            AttributedFeature(
                name="lowered_head_posture",
                specificity="low",
                onset_stage="middle",
                mechanism=None,
            )
        ],
        inspections=[RawInspectionAction(name="observe_breathing", instruction="Dengarkan napas")],
        mitigations=[RawMitigationAction(name="increase_ventilation", instruction="Naikkan ventilasi", priority="medium")],
        treatments=[RawMedicalTreatment(name="Amoxicillin", dosage="10mg/kg", withdrawal_period="7 hari")],
    )
    return GraphContext(candidates=[candidate_a, candidate_b])
