# Tahap 3 — Knowledge Graph (Ontologi, Schema, Seed Data)

Implementasi lengkap **Tahap 3: Knowledge Graph** dari panduan implementasi
Poultry GraphRAG-Vet.

## ⚠️ Batasan Validasi di Sandbox Ini (penting dibaca)

Docker **tidak tersedia** di sandbox tempat kode ini dibuat, dan Neo4j
tidak bisa diinstall langsung (perlu akses ke `debian.neo4j.com` yang
di luar jaringan yang diizinkan). Akibatnya:

| Yang SUDAH divalidasi di sini | Yang BELUM bisa divalidasi di sini |
|---|---|
| ✅ Sintaks YAML (`node_definitions.yaml`, dst) — di-parse dengan `pyyaml`, semua valid | ❌ Sintaks Cypher sungguhan (constraint/index/seed) — perlu Neo4j asli |
| ✅ Konsistensi nama entity seed vs `canonical_terms.yaml` — via `validate_seed_consistency.py` | ❌ Hasil query `retrieve_disease_context.cypher` terhadap data nyata |
| ✅ Semua relasi merujuk variabel node yang benar-benar didefinisikan | ❌ Performa query di skala data lebih besar |
| ✅ Tidak ada `CREATE` yang seharusnya `MERGE` | |
| ✅ Tidak ada `withdrawal_period` kosong | |
| ✅ Logika orkestrasi `bootstrap_neo4j.py` (idempotency, urutan folder, partial failure) — 9 unit test dengan fake session | |

**WAJIB dilakukan di komputer Anda setelah menerima paket ini:**
```bash
docker compose -f ops/docker/docker-compose.neo4j.yml up -d
# tunggu healthy, lalu:
python scripts/bootstrap_neo4j.py
# lalu verifikasi manual di Neo4j Browser (http://localhost:7474):
MATCH (d:Disease) RETURN d.name, d.base_severity ORDER BY d.name;
# harus tampil 8 penyakit
```

## ⚠️ Isi Klinis Seed Data — DRAFT, BELUM DIVALIDASI VET

8 penyakit di `cypher/seeds/001_seed_ontology.cypher` (Newcastle Disease,
Infectious Bronchitis, Avian Influenza, Coccidiosis, Infectious Coryza,
Fowl Cholera, Marek's Disease, Colibacillosis) disusun dari pengetahuan
umum kesehatan unggas — **BUKAN** hasil riset literatur sistematis
(textbook/OIE/dst) seperti direncanakan di Fase 2 timeline proyek.

**JANGAN dipakai untuk keputusan produksi/treatment sungguhan** sebelum
direview dokter hewan unggas berlisensi, terutama bagian:
- Dosis obat & withdrawal_period (paling kritis — keamanan pangan)
- Akurasi base_severity per penyakit
- Kelengkapan gejala (kemungkinan ada yang terlewat)

Checklist TODO validasi vet sudah dicantumkan di komentar bagian atas
file seed itu sendiri.

## Struktur File

```
src/poultry_graphrag/knowledge_graph/
├─ ontology/
│  ├─ node_definitions.yaml           # 7 node type + skema properti
│  └─ relationship_definitions.yaml   # 6 relationship type + skema properti
├─ cypher/
│  ├─ constraints/001_constraints.cypher
│  ├─ indexes/001_indexes.cypher
│  ├─ templates/retrieve_disease_context.cypher   # query utama Modul B
│  └─ seeds/001_seed_ontology.cypher              # 8 penyakit, ~40 node, ~100 relasi
└─ dictionaries/
   ├─ canonical_terms.yaml            # istilah resmi (8 visual, 10 symptom, 3 env)
   └─ synonym_dictionary.yaml         # variasi istilah -> canonical

scripts/
├─ bootstrap_neo4j.py              # jalankan constraints -> indexes -> seeds (idempotent)
└─ validate_seed_consistency.py    # validasi TANPA Neo4j (lihat tabel di atas)

tests/unit/scripts/
└─ test_bootstrap_neo4j.py         # 9 test, fake session, TIDAK butuh Neo4j nyata

ops/docker/docker-compose.neo4j.yml
.env.example
```

## Cara Pakai

1. Copy seluruh isi `src/`, `scripts/`, `tests/`, `ops/` ke lokasi yang
   sama persis di repo Anda.
2. `cp .env.example .env` lalu isi password Neo4j yang sesungguhnya.
3. `docker compose -f ops/docker/docker-compose.neo4j.yml up -d`
4. `pip install neo4j pyyaml`
5. `python scripts/validate_seed_consistency.py` (cepat, tanpa Neo4j — jalankan ini duluan)
6. `python scripts/bootstrap_neo4j.py` (butuh Neo4j sudah hidup)
7. `pytest tests/ -v` (9 test, tidak butuh Neo4j — murni logika)

## Cakupan Saat Ini vs Target Timeline

Timeline proyek (Fase 2) menargetkan **15–30 penyakit prioritas**. Paket
ini berisi **8 penyakit** sebagai pola/kerangka awal yang sudah teruji
strukturnya — memperluas ke lebih banyak penyakit tinggal mengikuti pola
yang sama persis di `001_seed_ontology.cypher`, atau tambahkan sebagai
`002_seed_ontology_batch2.cypher` (`bootstrap_neo4j.py` otomatis
mendeteksi file baru tanpa mengulang yang lama).
