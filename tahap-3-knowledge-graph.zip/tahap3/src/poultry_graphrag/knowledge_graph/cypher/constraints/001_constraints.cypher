// Constraint uniqueness untuk semua node type -- mencegah data duplikat
// meski seed script dijalankan berulang (dikombinasikan dengan MERGE,
// bukan CREATE, di file seed).

CREATE CONSTRAINT disease_id_unique IF NOT EXISTS FOR (d:Disease) REQUIRE d.id IS UNIQUE;
CREATE CONSTRAINT visualfeature_id_unique IF NOT EXISTS FOR (vf:VisualFeature) REQUIRE vf.id IS UNIQUE;
CREATE CONSTRAINT symptom_id_unique IF NOT EXISTS FOR (s:Symptom) REQUIRE s.id IS UNIQUE;
CREATE CONSTRAINT environmentalcondition_id_unique IF NOT EXISTS FOR (ec:EnvironmentalCondition) REQUIRE ec.id IS UNIQUE;
CREATE CONSTRAINT inspectionaction_id_unique IF NOT EXISTS FOR (ia:InspectionAction) REQUIRE ia.id IS UNIQUE;
CREATE CONSTRAINT mitigationaction_id_unique IF NOT EXISTS FOR (ma:MitigationAction) REQUIRE ma.id IS UNIQUE;
CREATE CONSTRAINT medicaltreatment_id_unique IF NOT EXISTS FOR (mt:MedicalTreatment) REQUIRE mt.id IS UNIQUE;

// Nama juga harus unik per tipe -- mencegah 2 node beda id tapi nama sama
// (yang akan membingungkan canonical_mapper.py di Tahap 6).
CREATE CONSTRAINT visualfeature_name_unique IF NOT EXISTS FOR (vf:VisualFeature) REQUIRE vf.name IS UNIQUE;
CREATE CONSTRAINT symptom_name_unique IF NOT EXISTS FOR (s:Symptom) REQUIRE s.name IS UNIQUE;
CREATE CONSTRAINT environmentalcondition_name_unique IF NOT EXISTS FOR (ec:EnvironmentalCondition) REQUIRE ec.name IS UNIQUE;
CREATE CONSTRAINT disease_name_unique IF NOT EXISTS FOR (d:Disease) REQUIRE d.name IS UNIQUE;
