// ============================================================================
// SEED DATA -- DRAFT AWAL, BELUM DIVALIDASI PAKAR VET.
//
// Isi file ini disusun dari pengetahuan umum kesehatan unggas yang lazim
// didokumentasikan (bukan hasil riset literatur sistematis seperti
// direncanakan di Fase 2 timeline: textbook, panduan OIE, dst).
//
// JANGAN dipakai untuk keputusan produksi/treatment sungguhan sebelum
// direview oleh dokter hewan unggas berlisensi. Tandai TODO di bawah
// sebagai checklist validasi.
//
// TODO validasi vet:
//   [ ] Akurasi base_severity per penyakit
//   [ ] Akurasi specificity/onset_stage per relasi gejala-penyakit
//   [ ] Dosis & withdrawal_period obat (KRUSIAL -- terkait keamanan pangan)
//   [ ] Kelengkapan gejala (kemungkinan ada gejala penting yang terlewat)
//   [ ] Referensi sumber literatur resmi untuk tiap klaim
//
// Aturan teknis:
//   - Pakai MERGE, BUKAN CREATE -- supaya idempotent (aman dijalankan ulang)
//   - Semua nama VisualFeature/Symptom/EnvironmentalCondition WAJIB match
//     persis dengan dictionaries/canonical_terms.yaml (divalidasi otomatis
//     oleh scripts/validate_seed_consistency.py)
// ============================================================================


// ----------------------------------------------------------------------
// SHARED NODES -- VisualFeature (dipakai lintas beberapa penyakit)
// ----------------------------------------------------------------------
MERGE (vf1:VisualFeature {id: "VF-001"}) SET vf1.name = "lowered_head_posture";
MERGE (vf2:VisualFeature {id: "VF-002"}) SET vf2.name = "irregular_feather_appearance";
MERGE (vf3:VisualFeature {id: "VF-003"}) SET vf3.name = "swollen_face";
MERGE (vf4:VisualFeature {id: "VF-004"}) SET vf4.name = "twisted_neck";
MERGE (vf5:VisualFeature {id: "VF-005"}) SET vf5.name = "pale_comb_and_wattles";
MERGE (vf6:VisualFeature {id: "VF-006"}) SET vf6.name = "huddling_behavior";
MERGE (vf7:VisualFeature {id: "VF-007"}) SET vf7.name = "ruffled_feathers";
MERGE (vf8:VisualFeature {id: "VF-008"}) SET vf8.name = "lethargic_movement";

// ----------------------------------------------------------------------
// SHARED NODES -- Symptom
// ----------------------------------------------------------------------
MERGE (sy1:Symptom {id: "SY-001"}) SET sy1.name = "respiratory_distress";
MERGE (sy2:Symptom {id: "SY-002"}) SET sy2.name = "greenish_diarrhea";
MERGE (sy3:Symptom {id: "SY-003"}) SET sy3.name = "bloody_diarrhea";
MERGE (sy4:Symptom {id: "SY-004"}) SET sy4.name = "nasal_discharge";
MERGE (sy5:Symptom {id: "SY-005"}) SET sy5.name = "coughing";
MERGE (sy6:Symptom {id: "SY-006"}) SET sy6.name = "reduced_egg_production";
MERGE (sy7:Symptom {id: "SY-007"}) SET sy7.name = "sudden_death";
MERGE (sy8:Symptom {id: "SY-008"}) SET sy8.name = "loss_of_appetite";
MERGE (sy9:Symptom {id: "SY-009"}) SET sy9.name = "watery_eyes";
MERGE (sy10:Symptom {id: "SY-010"}) SET sy10.name = "facial_swelling";

// ----------------------------------------------------------------------
// SHARED NODES -- EnvironmentalCondition
// ----------------------------------------------------------------------
MERGE (ec1:EnvironmentalCondition {id: "EC-001"}) SET ec1.name = "temperature_attention";
MERGE (ec2:EnvironmentalCondition {id: "EC-002"}) SET ec2.name = "humidity_attention";
MERGE (ec3:EnvironmentalCondition {id: "EC-003"}) SET ec3.name = "ammonia_attention";

// ----------------------------------------------------------------------
// SHARED NODES -- InspectionAction
// ----------------------------------------------------------------------
MERGE (ia1:InspectionAction {id: "IA-001"})
SET ia1.name = "observe_breathing",
    ia1.instruction = "Dengarkan suara napas ayam selama 30 detik dari jarak dekat, perhatikan bunyi ngorok/berdesis";

MERGE (ia2:InspectionAction {id: "IA-002"})
SET ia2.name = "check_nasal_discharge",
    ia2.instruction = "Periksa area hidung/nares untuk cairan atau kerak";

MERGE (ia3:InspectionAction {id: "IA-003"})
SET ia3.name = "check_droppings_consistency",
    ia3.instruction = "Periksa kotoran terbaru di sekitar cage untuk warna dan konsistensi tidak normal";

MERGE (ia4:InspectionAction {id: "IA-004"})
SET ia4.name = "check_activity_level",
    ia4.instruction = "Amati respons ayam terhadap rangsangan (suara/gerakan) selama 1 menit";

MERGE (ia5:InspectionAction {id: "IA-005"})
SET ia5.name = "inspect_comb_wattle_color",
    ia5.instruction = "Periksa warna jengger dan pial secara langsung, bandingkan dengan ayam sehat di sekitarnya";

MERGE (ia6:InspectionAction {id: "IA-006"})
SET ia6.name = "check_neck_posture",
    ia6.instruction = "Amati posisi leher saat ayam diam maupun bergerak, perhatikan tanda memutar/tortikolis";

// ----------------------------------------------------------------------
// SHARED NODES -- MitigationAction
// ----------------------------------------------------------------------
MERGE (ma1:MitigationAction {id: "MA-001"})
SET ma1.name = "increase_ventilation",
    ma1.instruction = "Naikkan kecepatan kipas ventilasi kandang untuk zona terkait",
    ma1.priority = "high";

MERGE (ma2:MitigationAction {id: "MA-002"})
SET ma2.name = "isolate_bird",
    ma2.instruction = "Pisahkan ayam dari populasi utama untuk mencegah penularan lebih lanjut",
    ma2.priority = "high";

MERGE (ma3:MitigationAction {id: "MA-003"})
SET ma3.name = "adjust_stocking_density",
    ma3.instruction = "Kurangi kepadatan kandang di zona terkait jika memungkinkan",
    ma3.priority = "medium";

MERGE (ma4:MitigationAction {id: "MA-004"})
SET ma4.name = "disinfect_housing",
    ma4.instruction = "Lakukan disinfeksi kandang dan peralatan sesuai protokol biosekuriti",
    ma4.priority = "high";

MERGE (ma5:MitigationAction {id: "MA-005"})
SET ma5.name = "provide_electrolytes",
    ma5.instruction = "Berikan larutan elektrolit/vitamin di air minum untuk mendukung pemulihan",
    ma5.priority = "medium";

MERGE (ma6:MitigationAction {id: "MA-006"})
SET ma6.name = "reduce_ammonia_exposure",
    ma6.instruction = "Perbaiki manajemen litter/alas kandang untuk menurunkan kadar amonia",
    ma6.priority = "medium";

// ----------------------------------------------------------------------
// SHARED NODES -- MedicalTreatment
// ----------------------------------------------------------------------
MERGE (mt1:MedicalTreatment {id: "MT-001"})
SET mt1.name = "Amoxicillin",
    mt1.dosage = "10-20mg/kg berat badan, 2x sehari, referensi umum",
    mt1.withdrawal_period = "7 hari (referensi umum, cek label produk aktual)";

MERGE (mt2:MedicalTreatment {id: "MT-002"})
SET mt2.name = "Amprolium (Anticoccidial)",
    mt2.dosage = "Sesuai petunjuk produk, biasanya via air minum 5-7 hari",
    mt2.withdrawal_period = "Tidak ada masa henti obat untuk telur pada dosis standar (VERIFIKASI ke label produk)";

MERGE (mt3:MedicalTreatment {id: "MT-003"})
SET mt3.name = "Sulfonamide (Sulfadimethoxine)",
    mt3.dosage = "Sesuai petunjuk produk, referensi umum",
    mt3.withdrawal_period = "5-10 hari (referensi umum, cek label produk aktual)";

MERGE (mt4:MedicalTreatment {id: "MT-004"})
SET mt4.name = "Terapi Suportif (Elektrolit + Vitamin)",
    mt4.dosage = "Sesuai kondisi klinis -- bukan terapi antibiotik",
    mt4.withdrawal_period = "Tidak berlaku";


// ============================================================================
// DIS-001: Newcastle Disease (Viral, Notifiable)
// ============================================================================
MERGE (d1:Disease {id: "DIS-001"})
SET d1.name = "Newcastle Disease",
    d1.desc = "Penyakit viral menular yang menyerang sistem saraf dan pernapasan unggas, sangat menular antar kandang",
    d1.base_severity = "critical",
    d1.notifiable = true;

MERGE (d1)-[:HAS_VISUAL_FEATURE {specificity: "high", onset_stage: "early", mechanism: "gangguan neurologis awal akibat infeksi virus paramyxovirus"}]->(vf1);
MERGE (d1)-[:HAS_VISUAL_FEATURE {specificity: "high", onset_stage: "middle", mechanism: "kerusakan sistem saraf pusat progresif"}]->(vf4);
MERGE (d1)-[:HAS_VISUAL_FEATURE {specificity: "low", onset_stage: "early", mechanism: "respons umum terhadap infeksi sistemik"}]->(vf8);
MERGE (d1)-[:HAS_SYMPTOM {specificity: "medium", onset_stage: "early", mechanism: "keterlibatan saluran pernapasan"}]->(sy1);
MERGE (d1)-[:HAS_SYMPTOM {specificity: "medium", onset_stage: "middle", mechanism: "keterlibatan saluran cerna"}]->(sy2);
MERGE (d1)-[:HAS_SYMPTOM {specificity: "high", onset_stage: "middle", mechanism: "penurunan produksi akibat stres sistemik"}]->(sy6);
MERGE (d1)-[:HAS_SYMPTOM {specificity: "low", onset_stage: "late", mechanism: "kegagalan sistemik pada kasus akut berat"}]->(sy7);
MERGE (d1)-[:REQUIRES_INSPECTION]->(ia6);
MERGE (d1)-[:REQUIRES_INSPECTION]->(ia1);
MERGE (d1)-[:REQUIRES_INSPECTION]->(ia4);
MERGE (d1)-[:MITIGATED_BY]->(ma2);
MERGE (d1)-[:MITIGATED_BY]->(ma4);
MERGE (d1)-[:TREATED_WITH {dosage: "Tidak ada terapi antivirus spesifik -- fokus pencegahan sekunder & suportif", withdrawal_period: "Tidak berlaku"}]->(mt4);


// ============================================================================
// DIS-002: Infectious Bronchitis (Viral, Respiratory)
// ============================================================================
MERGE (d2:Disease {id: "DIS-002"})
SET d2.name = "Infectious Bronchitis",
    d2.desc = "Penyakit viral pada saluran pernapasan unggas, dapat berdampak signifikan pada produksi telur",
    d2.base_severity = "medium",
    d2.notifiable = false;

MERGE (d2)-[:HAS_VISUAL_FEATURE {specificity: "low", onset_stage: "early", mechanism: "respons umum terhadap infeksi saluran napas"}]->(vf8);
MERGE (d2)-[:HAS_VISUAL_FEATURE {specificity: "low", onset_stage: "middle", mechanism: "ketidaknyamanan sistemik"}]->(vf7);
MERGE (d2)-[:HAS_SYMPTOM {specificity: "high", onset_stage: "early", mechanism: "peradangan trakea dan bronkus"}]->(sy5);
MERGE (d2)-[:HAS_SYMPTOM {specificity: "high", onset_stage: "early", mechanism: "peradangan saluran napas atas"}]->(sy4);
MERGE (d2)-[:HAS_SYMPTOM {specificity: "high", onset_stage: "middle", mechanism: "kerusakan pada saluran reproduksi akibat infeksi sistemik"}]->(sy6);
MERGE (d2)-[:ASSOCIATED_WITH_ENVIRONMENT {strength: "medium"}]->(ec1);
MERGE (d2)-[:ASSOCIATED_WITH_ENVIRONMENT {strength: "medium"}]->(ec2);
MERGE (d2)-[:REQUIRES_INSPECTION]->(ia1);
MERGE (d2)-[:REQUIRES_INSPECTION]->(ia2);
MERGE (d2)-[:MITIGATED_BY]->(ma1);
MERGE (d2)-[:MITIGATED_BY]->(ma3);
MERGE (d2)-[:TREATED_WITH {dosage: "Tidak ada terapi antivirus spesifik -- kendalikan infeksi bakteri sekunder bila ada", withdrawal_period: "Tidak berlaku untuk terapi suportif"}]->(mt4);
MERGE (d2)-[:TREATED_WITH {dosage: "10-20mg/kg BB, 2x sehari (untuk infeksi sekunder bakteri)", withdrawal_period: "7 hari (referensi umum, cek label produk aktual)"}]->(mt1);


// ============================================================================
// DIS-003: Highly Pathogenic Avian Influenza (Viral, CRITICAL, Notifiable)
// ============================================================================
MERGE (d3:Disease {id: "DIS-003"})
SET d3.name = "Highly Pathogenic Avian Influenza",
    d3.desc = "Penyakit viral sangat menular dan berbahaya, wajib dilaporkan segera ke otoritas kesehatan hewan setempat",
    d3.base_severity = "critical",
    d3.notifiable = true;

MERGE (d3)-[:HAS_VISUAL_FEATURE {specificity: "high", onset_stage: "early", mechanism: "gangguan sistemik akut akibat infeksi virus"}]->(vf8);
MERGE (d3)-[:HAS_VISUAL_FEATURE {specificity: "medium", onset_stage: "early", mechanism: "edema jaringan lunak wajah"}]->(vf3);
MERGE (d3)-[:HAS_VISUAL_FEATURE {specificity: "medium", onset_stage: "middle", mechanism: "gangguan sirkulasi perifer"}]->(vf5);
MERGE (d3)-[:HAS_SYMPTOM {specificity: "high", onset_stage: "early", mechanism: "keterlibatan sistemik multi-organ akut"}]->(sy1);
MERGE (d3)-[:HAS_SYMPTOM {specificity: "high", onset_stage: "late", mechanism: "kegagalan sistemik akut, mortalitas tinggi"}]->(sy7);
MERGE (d3)-[:REQUIRES_INSPECTION]->(ia5);
MERGE (d3)-[:REQUIRES_INSPECTION]->(ia1);
MERGE (d3)-[:REQUIRES_INSPECTION]->(ia4);
MERGE (d3)-[:MITIGATED_BY]->(ma2);
MERGE (d3)-[:MITIGATED_BY]->(ma4);
MERGE (d3)-[:TREATED_WITH {dosage: "TIDAK ADA terapi -- WAJIB lapor otoritas kesehatan hewan setempat segera, ikuti protokol biosekuriti darurat", withdrawal_period: "Tidak berlaku"}]->(mt4);


// ============================================================================
// DIS-004: Coccidiosis (Parasit)
// ============================================================================
MERGE (d4:Disease {id: "DIS-004"})
SET d4.name = "Coccidiosis",
    d4.desc = "Infeksi parasit protozoa pada saluran pencernaan, umum terjadi pada kondisi litter lembap",
    d4.base_severity = "medium",
    d4.notifiable = false;

MERGE (d4)-[:HAS_VISUAL_FEATURE {specificity: "medium", onset_stage: "middle", mechanism: "respons terhadap kehilangan darah dan nutrisi"}]->(vf8);
MERGE (d4)-[:HAS_VISUAL_FEATURE {specificity: "low", onset_stage: "middle", mechanism: "ketidaknyamanan sistemik"}]->(vf7);
MERGE (d4)-[:HAS_SYMPTOM {specificity: "high", onset_stage: "middle", mechanism: "kerusakan mukosa usus akibat siklus hidup parasit"}]->(sy3);
MERGE (d4)-[:HAS_SYMPTOM {specificity: "medium", onset_stage: "early", mechanism: "gangguan penyerapan nutrisi"}]->(sy8);
MERGE (d4)-[:ASSOCIATED_WITH_ENVIRONMENT {strength: "high"}]->(ec2);
MERGE (d4)-[:REQUIRES_INSPECTION]->(ia3);
MERGE (d4)-[:REQUIRES_INSPECTION]->(ia4);
MERGE (d4)-[:MITIGATED_BY]->(ma6);
MERGE (d4)-[:MITIGATED_BY]->(ma5);
MERGE (d4)-[:TREATED_WITH {dosage: "Sesuai petunjuk produk, biasanya via air minum 5-7 hari", withdrawal_period: "Tidak ada masa henti obat untuk telur pada dosis standar (VERIFIKASI ke label produk)"}]->(mt2);


// ============================================================================
// DIS-005: Infectious Coryza (Bakteri)
// ============================================================================
MERGE (d5:Disease {id: "DIS-005"})
SET d5.name = "Infectious Coryza",
    d5.desc = "Infeksi bakteri akut pada saluran pernapasan atas, ditandai pembengkakan wajah",
    d5.base_severity = "medium",
    d5.notifiable = false;

MERGE (d5)-[:HAS_VISUAL_FEATURE {specificity: "high", onset_stage: "early", mechanism: "edema jaringan akibat infeksi bakteri lokal"}]->(vf3);
MERGE (d5)-[:HAS_SYMPTOM {specificity: "high", onset_stage: "early", mechanism: "peradangan mukosa nasal"}]->(sy4);
MERGE (d5)-[:HAS_SYMPTOM {specificity: "high", onset_stage: "early", mechanism: "peradangan konjungtiva"}]->(sy9);
MERGE (d5)-[:HAS_SYMPTOM {specificity: "high", onset_stage: "middle", mechanism: "edema jaringan wajah akibat infeksi lokal"}]->(sy10);
MERGE (d5)-[:REQUIRES_INSPECTION]->(ia2);
MERGE (d5)-[:REQUIRES_INSPECTION]->(ia5);
MERGE (d5)-[:MITIGATED_BY]->(ma2);
MERGE (d5)-[:MITIGATED_BY]->(ma1);
MERGE (d5)-[:TREATED_WITH {dosage: "Sesuai petunjuk produk, referensi umum", withdrawal_period: "5-10 hari (referensi umum, cek label produk aktual)"}]->(mt3);


// ============================================================================
// DIS-006: Fowl Cholera (Bakteri)
// ============================================================================
MERGE (d6:Disease {id: "DIS-006"})
SET d6.name = "Fowl Cholera",
    d6.desc = "Infeksi bakteri sistemik yang dapat berkembang cepat, mortalitas tinggi pada kasus akut",
    d6.base_severity = "high",
    d6.notifiable = false;

MERGE (d6)-[:HAS_VISUAL_FEATURE {specificity: "medium", onset_stage: "middle", mechanism: "edema jaringan lunak akibat infeksi sistemik"}]->(vf3);
MERGE (d6)-[:HAS_VISUAL_FEATURE {specificity: "low", onset_stage: "early", mechanism: "respons sistemik terhadap infeksi"}]->(vf8);
MERGE (d6)-[:HAS_SYMPTOM {specificity: "high", onset_stage: "late", mechanism: "septikemia akut"}]->(sy7);
MERGE (d6)-[:HAS_SYMPTOM {specificity: "medium", onset_stage: "middle", mechanism: "keterlibatan saluran cerna sistemik"}]->(sy2);
MERGE (d6)-[:REQUIRES_INSPECTION]->(ia5);
MERGE (d6)-[:REQUIRES_INSPECTION]->(ia3);
MERGE (d6)-[:MITIGATED_BY]->(ma2);
MERGE (d6)-[:MITIGATED_BY]->(ma4);
MERGE (d6)-[:TREATED_WITH {dosage: "10-20mg/kg BB, 2x sehari, referensi umum", withdrawal_period: "7 hari (referensi umum, cek label produk aktual)"}]->(mt1);


// ============================================================================
// DIS-007: Marek's Disease (Viral, Kronis)
// ============================================================================
MERGE (d7:Disease {id: "DIS-007"})
SET d7.name = "Marek's Disease",
    d7.desc = "Penyakit viral kronis yang menyerang sistem saraf, biasanya berkembang bertahap",
    d7.base_severity = "high",
    d7.notifiable = false;

MERGE (d7)-[:HAS_VISUAL_FEATURE {specificity: "high", onset_stage: "late", mechanism: "kerusakan saraf perifer progresif akibat infeksi virus herpes"}]->(vf4);
MERGE (d7)-[:HAS_VISUAL_FEATURE {specificity: "medium", onset_stage: "middle", mechanism: "kelemahan progresif akibat keterlibatan saraf"}]->(vf8);
MERGE (d7)-[:HAS_SYMPTOM {specificity: "low", onset_stage: "middle", mechanism: "penurunan kondisi umum akibat penyakit kronis"}]->(sy8);
MERGE (d7)-[:REQUIRES_INSPECTION]->(ia6);
MERGE (d7)-[:REQUIRES_INSPECTION]->(ia4);
MERGE (d7)-[:MITIGATED_BY]->(ma2);
MERGE (d7)-[:TREATED_WITH {dosage: "Tidak ada terapi kuratif -- fokus pada manajemen suportif dan pencegahan penyebaran", withdrawal_period: "Tidak berlaku"}]->(mt4);


// ============================================================================
// DIS-008: Colibacillosis (Bakteri, E. coli)
// ============================================================================
MERGE (d8:Disease {id: "DIS-008"})
SET d8.name = "Colibacillosis",
    d8.desc = "Infeksi bakteri E. coli oportunistik, sering terkait kualitas lingkungan kandang yang buruk",
    d8.base_severity = "medium",
    d8.notifiable = false;

MERGE (d8)-[:HAS_VISUAL_FEATURE {specificity: "low", onset_stage: "early", mechanism: "respons sistemik terhadap infeksi bakteri"}]->(vf8);
MERGE (d8)-[:HAS_SYMPTOM {specificity: "medium", onset_stage: "early", mechanism: "keterlibatan kantung udara dan saluran napas"}]->(sy1);
MERGE (d8)-[:HAS_SYMPTOM {specificity: "medium", onset_stage: "middle", mechanism: "keterlibatan saluran cerna sekunder"}]->(sy2);
MERGE (d8)-[:HAS_SYMPTOM {specificity: "medium", onset_stage: "middle", mechanism: "dampak sistemik terhadap saluran reproduksi"}]->(sy6);
MERGE (d8)-[:ASSOCIATED_WITH_ENVIRONMENT {strength: "high"}]->(ec3);
MERGE (d8)-[:ASSOCIATED_WITH_ENVIRONMENT {strength: "medium"}]->(ec2);
MERGE (d8)-[:REQUIRES_INSPECTION]->(ia1);
MERGE (d8)-[:REQUIRES_INSPECTION]->(ia3);
MERGE (d8)-[:MITIGATED_BY]->(ma6);
MERGE (d8)-[:MITIGATED_BY]->(ma4);
MERGE (d8)-[:TREATED_WITH {dosage: "10-20mg/kg BB, 2x sehari, referensi umum", withdrawal_period: "7 hari (referensi umum, cek label produk aktual)"}]->(mt1);
