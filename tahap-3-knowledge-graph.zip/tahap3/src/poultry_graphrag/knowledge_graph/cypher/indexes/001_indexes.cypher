// Index tambahan di kolom yang dipakai WHERE pada query retrieval utama
// (lihat cypher/templates/retrieve_disease_context.cypher). Constraint
// uniqueness di 001_constraints.cypher sudah otomatis membuat index,
// tapi kita eksplisitkan di sini untuk kejelasan + index non-unique
// yang tidak tercover constraint.

CREATE INDEX inspectionaction_name_idx IF NOT EXISTS FOR (ia:InspectionAction) ON (ia.name);
CREATE INDEX mitigationaction_name_idx IF NOT EXISTS FOR (ma:MitigationAction) ON (ma.name);
CREATE INDEX medicaltreatment_name_idx IF NOT EXISTS FOR (mt:MedicalTreatment) ON (mt.name);
CREATE INDEX disease_base_severity_idx IF NOT EXISTS FOR (d:Disease) ON (d.base_severity);
