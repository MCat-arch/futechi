"""
Jalankan schema initialization Neo4j: constraints -> indexes -> seeds.
Aman dijalankan berulang kali (idempotent) -- melacak file yang sudah
diterapkan lewat node _SchemaMigration di Neo4j itu sendiri.

Usage:
    python scripts/bootstrap_neo4j.py
"""
import os
import sys
import time
from pathlib import Path

from neo4j import GraphDatabase
from neo4j.exceptions import ServiceUnavailable

CYPHER_ROOT = (
    Path(__file__).parent.parent
    / "src" / "poultry_graphrag" / "knowledge_graph" / "cypher"
)

# Urutan folder WAJIB seperti ini: constraint dulu, baru index, baru seed
# data. Kalau dibalik, seed bisa gagal karena constraint belum ada.
ORDERED_FOLDERS = ["constraints", "indexes", "seeds"]


def get_connection_params() -> tuple[str, str, str]:
    """Baca env var di titik ini (bukan di module level) supaya file ini
    tetap bisa di-import untuk unit test tanpa perlu env var ter-set."""
    return (
        os.environ["NEO4J_URI"],
        os.environ["NEO4J_USERNAME"],
        os.environ["NEO4J_PASSWORD"],
    )


def wait_for_neo4j(driver, max_retries: int = 10, delay_seconds: int = 3) -> None:
    """Retry sampai Neo4j benar-benar siap menerima koneksi."""
    for attempt in range(1, max_retries + 1):
        try:
            driver.verify_connectivity()
            print("Neo4j siap.")
            return
        except ServiceUnavailable:
            print(f"Neo4j belum siap, percobaan {attempt}/{max_retries}...")
            time.sleep(delay_seconds)
    raise RuntimeError("Neo4j tidak merespons setelah beberapa kali percobaan.")


def get_applied_migrations(session) -> set[str]:
    result = session.run("MATCH (m:_SchemaMigration) RETURN m.filename AS filename")
    return {record["filename"] for record in result}


def mark_applied(session, filename: str) -> None:
    session.run(
        "MERGE (m:_SchemaMigration {filename: $filename}) "
        "SET m.applied_at = datetime()",
        filename=filename,
    )


def split_statements(cypher_text: str) -> list[str]:
    """
    Pisahkan file .cypher jadi statement per statement berdasarkan ';'.

    Catatan: pemisahan naif ini cukup untuk seed data kita karena tidak
    ada ';' di dalam string literal manapun. Kalau nanti ada nilai yang
    butuh ';' literal, pertimbangkan 1 statement per file sebagai
    konvensi, bukan multi-statement per file.

    Baris komentar (diawali '//') dan baris kosong diabaikan SEBELUM
    splitting, supaya tidak mengganggu parsing.
    """
    lines = [
        line for line in cypher_text.splitlines()
        if not line.strip().startswith("//")
    ]
    cleaned_text = "\n".join(lines)
    return [stmt.strip() for stmt in cleaned_text.split(";") if stmt.strip()]


def run_cypher_file(session, filepath: Path) -> None:
    content = filepath.read_text(encoding="utf-8")
    for statement in split_statements(content):
        session.run(statement)


def bootstrap(cypher_root: Path = CYPHER_ROOT) -> None:
    uri, user, password = get_connection_params()
    driver = GraphDatabase.driver(uri, auth=(user, password))
    wait_for_neo4j(driver)

    with driver.session() as session:
        applied = get_applied_migrations(session)

        for folder_name in ORDERED_FOLDERS:
            folder_path = cypher_root / folder_name
            if not folder_path.exists():
                print(f"Lewati folder yang tidak ada: {folder_path}")
                continue

            cypher_files = sorted(folder_path.glob("*.cypher"))
            for filepath in cypher_files:
                relative_name = f"{folder_name}/{filepath.name}"

                if relative_name in applied:
                    print(f"LEWATI (sudah diterapkan): {relative_name}")
                    continue

                print(f"MENERAPKAN: {relative_name}")
                try:
                    run_cypher_file(session, filepath)
                    mark_applied(session, relative_name)
                except Exception as exc:
                    print(f"GAGAL menerapkan {relative_name}: {exc}")
                    driver.close()
                    sys.exit(1)

    driver.close()
    print("Bootstrap selesai.")


if __name__ == "__main__":
    bootstrap()
