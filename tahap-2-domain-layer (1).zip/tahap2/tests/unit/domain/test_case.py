"""Unit test untuk domain/entities/case.py"""
from datetime import datetime, timedelta

import pytest

from poultry_graphrag.domain.entities.case import Case
from poultry_graphrag.domain.exceptions import CaseAlreadyResolvedError
from poultry_graphrag.domain.value_objects.enums import (
    CaseStatus,
    ConfirmationType,
    DetectionSession,
)
from poultry_graphrag.domain.value_objects.observations import (
    DiseaseActionBundle,
    EnvironmentSnapshot,
    InspectionAction,
    MedicalReference,
    MitigationAction,
    RelatedCondition,
    VisualFeatureObservation,
)
from poultry_graphrag.domain.value_objects.severity import compute_severity

NOW = datetime(2026, 8, 27, 8, 0, 0)


def _sample_environment() -> EnvironmentSnapshot:
    return EnvironmentSnapshot(
        temperature_c=30.5,
        humidity_percent=76,
        ammonia_ppm=22,
        normalized_conditions=("humidity_attention", "ammonia_attention"),
    )


def _new_case(now: datetime = NOW) -> Case:
    return Case.create_new(
        case_id="CASE-001",
        cage_id="B40",
        session=DetectionSession.MORNING,
        visual_features=[
            VisualFeatureObservation(name="lowered_head_posture", confidence=0.88)
        ],
        environment_snapshot=_sample_environment(),
        now=now,
    )


def _sample_disease_actions() -> dict[str, DiseaseActionBundle]:
    """Dua kandidat penyakit, masing-masing dengan mitigasi & referensi obat sendiri."""
    return {
        "Newcastle Disease": DiseaseActionBundle(
            disease_name="Newcastle Disease",
            mitigations=(
                MitigationAction(
                    name="increase_ventilation",
                    instruction="Naikkan kecepatan kipas ventilasi",
                    priority="high",
                ),
            ),
            medical_references=(
                MedicalReference(
                    for_condition="Newcastle Disease",
                    treatment_name="Amoxicillin",
                    dosage="10mg/kg BB, 2x sehari",
                    withdrawal_period="7 hari",
                ),
            ),
        ),
        "Infectious Bronchitis": DiseaseActionBundle(
            disease_name="Infectious Bronchitis",
            mitigations=(
                MitigationAction(
                    name="isolate_bird",
                    instruction="Pisahkan ayam dari kandang utama",
                    priority="medium",
                ),
            ),
            medical_references=(),
        ),
    }


def _sample_related_conditions() -> list[RelatedCondition]:
    return [
        RelatedCondition(
            disease_name="Newcastle Disease",
            evidence=("lowered_head_posture (high specificity, early stage)",),
            differential_note="Lebih mungkin dibanding kandidat lain",
        ),
        RelatedCondition(
            disease_name="Infectious Bronchitis",
            evidence=("lowered_head_posture (low specificity)",),
            differential_note="Kurang didukung, gejala kurang spesifik",
        ),
    ]


def _sample_checks() -> list[InspectionAction]:
    return [
        InspectionAction(
            name="observe_breathing",
            instruction="Dengarkan suara napas ayam selama 30 detik",
        )
    ]


# ----------------------------------------------------------------------
# create_new
# ----------------------------------------------------------------------
def test_create_new_case_has_detected_status_and_alert_count_one():
    case = _new_case()
    assert case.status == CaseStatus.DETECTED
    assert case.alert_count == 1
    assert len(case.detection_sessions) == 1
    assert not case.is_resolved()


# ----------------------------------------------------------------------
# merge_new_detection
# ----------------------------------------------------------------------
def test_merge_new_detection_increments_alert_count():
    case = _new_case()
    later = NOW + timedelta(hours=2)

    case.merge_new_detection(
        session=DetectionSession.EVENING,
        visual_features=[
            VisualFeatureObservation(name="irregular_feather_appearance", confidence=0.74)
        ],
        environment_snapshot=_sample_environment(),
        now=later,
    )

    assert case.alert_count == 2
    assert case.detection_sessions == [DetectionSession.MORNING, DetectionSession.EVENING]
    assert case.last_detected_at == later


def test_merge_new_detection_deduplicates_feature_by_name():
    case = _new_case()  # sudah punya "lowered_head_posture"
    case.merge_new_detection(
        session=DetectionSession.EVENING,
        visual_features=[
            VisualFeatureObservation(name="lowered_head_posture", confidence=0.95),  # duplikat
            VisualFeatureObservation(name="irregular_feather_appearance", confidence=0.74),
        ],
        environment_snapshot=_sample_environment(),
        now=NOW + timedelta(hours=2),
    )

    feature_names = [f.name for f in case.visual_features]
    assert feature_names.count("lowered_head_posture") == 1
    assert "irregular_feather_appearance" in feature_names
    assert len(case.visual_features) == 2


def test_merge_new_detection_raises_if_resolved_same_day():
    case = _new_case()
    case.resolve(ConfirmationType.HEALTHY, confirmed_by="user-1", now=NOW)

    with pytest.raises(CaseAlreadyResolvedError):
        case.merge_new_detection(
            session=DetectionSession.EVENING,
            visual_features=[],
            environment_snapshot=_sample_environment(),
            now=NOW + timedelta(hours=1),  # masih hari yang sama
        )


def test_merge_new_detection_allowed_if_resolved_different_day():
    """Kasus edge: case resolved kemarin, tapi entah kenapa masih ada
    percobaan merge di hari berikutnya -- ini seharusnya TIDAK dianggap
    'hari yang sama' sehingga tidak raise CaseAlreadyResolvedError.
    """
    case = _new_case()
    case.resolve(ConfirmationType.HEALTHY, confirmed_by="user-1", now=NOW)

    next_day = NOW + timedelta(days=1)
    case.merge_new_detection(
        session=DetectionSession.MORNING,
        visual_features=[],
        environment_snapshot=_sample_environment(),
        now=next_day,
    )
    assert case.alert_count == 2


# ----------------------------------------------------------------------
# attach_reasoning_result -- TAHAP 1 (langsung tampil)
# ----------------------------------------------------------------------
def test_attach_reasoning_result_sets_pending_confirmation():
    case = _new_case()
    conditions = _sample_related_conditions()
    checks = _sample_checks()
    disease_actions = _sample_disease_actions()
    severity = compute_severity(base_severity="high", onset_stage="early")

    case.attach_reasoning_result(conditions, checks, disease_actions, severity)

    assert case.status == CaseStatus.PENDING_CONFIRMATION
    assert case.related_conditions == conditions
    assert case.recommended_checks == checks
    assert case.severity == severity


def test_attach_reasoning_result_does_not_reveal_mitigations_or_medical_refs_yet():
    """Ini inti dari perbaikan: mitigasi & referensi medis TIDAK boleh
    langsung tampil begitu case dibuat -- baru muncul setelah user
    konfirmasi 'Sakit' dengan penyakit spesifik."""
    case = _new_case()
    case.attach_reasoning_result(
        _sample_related_conditions(),
        _sample_checks(),
        _sample_disease_actions(),
        severity=None,
    )

    assert case.recommended_mitigations == []
    assert case.medical_references == []


def test_mark_insufficient_data_still_sets_pending_confirmation_but_empty():
    case = _new_case()
    case.mark_insufficient_data()

    assert case.status == CaseStatus.PENDING_CONFIRMATION
    assert case.related_conditions == []
    assert case.recommended_checks == []
    assert case.recommended_mitigations == []
    assert case.medical_references == []


# ----------------------------------------------------------------------
# resolve -- TAHAP 2 (mitigasi & obat baru terbuka di sini, khusus SICK)
# ----------------------------------------------------------------------
def test_resolve_sick_reveals_mitigations_and_medical_refs_for_confirmed_disease_only():
    case = _new_case()
    case.attach_reasoning_result(
        _sample_related_conditions(),
        _sample_checks(),
        _sample_disease_actions(),
        severity=None,
    )

    case.resolve(
        ConfirmationType.SICK,
        confirmed_by="vet-1",
        now=NOW,
        confirmed_condition="Newcastle Disease",
    )

    assert case.status == CaseStatus.CONFIRMED_SICK
    # hanya mitigasi & obat untuk Newcastle Disease yang terbuka,
    # BUKAN gabungan semua kandidat (Infectious Bronchitis tidak ikut)
    assert len(case.recommended_mitigations) == 1
    assert case.recommended_mitigations[0].name == "increase_ventilation"
    assert len(case.medical_references) == 1
    assert case.medical_references[0].treatment_name == "Amoxicillin"


def test_resolve_sick_with_different_confirmed_disease_reveals_different_actions():
    case = _new_case()
    case.attach_reasoning_result(
        _sample_related_conditions(),
        _sample_checks(),
        _sample_disease_actions(),
        severity=None,
    )

    case.resolve(
        ConfirmationType.SICK,
        confirmed_by="vet-1",
        now=NOW,
        confirmed_condition="Infectious Bronchitis",
    )

    assert case.recommended_mitigations[0].name == "isolate_bird"
    assert case.medical_references == []  # memang tidak ada referensi obat utk kondisi ini


def test_resolve_sick_without_confirmed_condition_raises():
    case = _new_case()
    with pytest.raises(ValueError):
        case.resolve(ConfirmationType.SICK, confirmed_by="vet-1", now=NOW)


def test_resolve_sick_with_unknown_disease_name_results_in_empty_actions():
    """Kasus tepi: user memilih nama penyakit yang tidak ada di
    _disease_actions (mis. data tidak sinkron). Tidak boleh crash --
    cukup kosongkan mitigasi/referensi, biar use case layer yang
    menampilkan pesan fallback ke user."""
    case = _new_case()
    case.attach_reasoning_result(
        _sample_related_conditions(),
        _sample_checks(),
        _sample_disease_actions(),
        severity=None,
    )

    case.resolve(
        ConfirmationType.SICK,
        confirmed_by="vet-1",
        now=NOW,
        confirmed_condition="Penyakit Tidak Dikenal",
    )

    assert case.recommended_mitigations == []
    assert case.medical_references == []


@pytest.mark.parametrize(
    "confirmation_type,expected_status",
    [
        (ConfirmationType.NOT_SICK, CaseStatus.CONFIRMED_NOT_SICK),
        (ConfirmationType.HEALTHY, CaseStatus.CONFIRMED_HEALTHY),
    ],
)
def test_resolve_not_sick_or_healthy_does_not_require_confirmed_condition(
    confirmation_type, expected_status
):
    case = _new_case()
    case.resolve(confirmation_type, confirmed_by="petugas-1", now=NOW)

    assert case.status == expected_status
    assert case.confirmed_by == "petugas-1"
    assert case.resolved_at == NOW
    assert case.is_resolved() is True
    # tidak ada mitigasi/obat karena bukan konfirmasi sakit
    assert case.recommended_mitigations == []
    assert case.medical_references == []


# ----------------------------------------------------------------------
# TTL & escalation
# ----------------------------------------------------------------------
def test_is_ttl_expired_true_after_deadline_when_pending():
    case = _new_case()
    case.status = CaseStatus.PENDING_CONFIRMATION

    assert case.is_ttl_expired(ttl_hours=24, now=NOW + timedelta(hours=25)) is True
    assert case.is_ttl_expired(ttl_hours=24, now=NOW + timedelta(hours=10)) is False


def test_is_ttl_expired_false_if_not_pending_even_past_deadline():
    case = _new_case()
    case.status = CaseStatus.CONFIRMED_SICK

    assert case.is_ttl_expired(ttl_hours=24, now=NOW + timedelta(hours=48)) is False


def test_escalate_unconfirmed_only_effective_from_pending_status():
    case = _new_case()  # status DETECTED
    case.escalate_unconfirmed()
    assert case.status == CaseStatus.DETECTED

    case.status = CaseStatus.PENDING_CONFIRMATION
    case.escalate_unconfirmed()
    assert case.status == CaseStatus.UNCONFIRMED_ESCALATED


# ----------------------------------------------------------------------
# known_candidate_diseases (helper untuk validasi confirmed_condition di use case)
# ----------------------------------------------------------------------
def test_known_candidate_diseases_returns_names_from_related_conditions():
    case = _new_case()
    case.attach_reasoning_result(
        _sample_related_conditions(),
        _sample_checks(),
        _sample_disease_actions(),
        severity=None,
    )
    assert case.known_candidate_diseases() == ("Newcastle Disease", "Infectious Bronchitis")
