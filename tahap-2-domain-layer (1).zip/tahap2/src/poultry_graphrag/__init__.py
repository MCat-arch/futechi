"""Poultry GraphRAG-Vet — package utama."""

__version__ = "0.1.0"
